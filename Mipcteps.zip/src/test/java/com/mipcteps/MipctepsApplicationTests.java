package com.mipcteps;


import com.mipcteps.common.storage.CacheStorage;
import com.mipcteps.common.utils.ServletUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Collection;
import java.util.List;


@SpringBootTest
public class MipctepsApplicationTests {

    @Autowired
    CacheStorage storage;

    @Test
    public void dada(){
        /*long week = 7*24*60*60*1000L;*/
    }

}
