
const authToken = 'token';

const verifyId = 'verifyid';

const server = {'ip':'http://127.5.4.8:','port':'7012'};

const http = server.ip+server.port

