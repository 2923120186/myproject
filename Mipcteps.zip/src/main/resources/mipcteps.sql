/*
 Navicat Premium Data Transfer

 Source Server         : yrc
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : mipcteps

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 10/03/2022 00:19:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for authority_role
-- ----------------------------
DROP TABLE IF EXISTS `authority_role`;
CREATE TABLE `authority_role`  (
  `authorityid` int(0) NOT NULL,
  `roleid` int(0) NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of authority_role
-- ----------------------------
INSERT INTO `authority_role` VALUES (1, 2);
INSERT INTO `authority_role` VALUES (2, 3);

-- ----------------------------
-- Table structure for authorize
-- ----------------------------
DROP TABLE IF EXISTS `authorize`;
CREATE TABLE `authorize`  (
  `authorizeid` int(0) NOT NULL,
  `authorizename` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of authorize
-- ----------------------------
INSERT INTO `authorize` VALUES (1, 'sys:info:edit');
INSERT INTO `authorize` VALUES (1, 'sys:info:save');
INSERT INTO `authorize` VALUES (1, 'sys:info:remove');
INSERT INTO `authorize` VALUES (2, 'sys:info:show');
INSERT INTO `authorize` VALUES (2, 'sys:info:download');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `roleid` int(0) NOT NULL,
  `rolename` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (2, 'manage');
INSERT INTO `role` VALUES (1, 'admin');
INSERT INTO `role` VALUES (3, 'common');

-- ----------------------------
-- Table structure for role_authorize
-- ----------------------------
DROP TABLE IF EXISTS `role_authorize`;
CREATE TABLE `role_authorize`  (
  `roleid` int(0) NOT NULL,
  `authorizeid` int(0) NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_authorize
-- ----------------------------
INSERT INTO `role_authorize` VALUES (2, 1);
INSERT INTO `role_authorize` VALUES (1, 3);
INSERT INTO `role_authorize` VALUES (3, 2);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `userid` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户编号',
  `sex` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '保密' COMMENT '性别',
  `authorityid` int(0) NOT NULL COMMENT '授权标识',
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '描述',
  `createdate` date NOT NULL COMMENT '注册时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_userid`(`userid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1007 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1001, 'chichu', '$2a$10$XHsU1OgnMlHlz7xf3AUp/uElMXKK7rTktfapTr//sqQvZXIxq/HfC', 'f347a91c716f11eca9f1604', '男', 1, 'i name chichu', '2022-01-09');
INSERT INTO `user` VALUES (1002, 'wdc', '$2a$10$mIEh50ghZ2KbnkT4/1mfTuIXc/1SEqsD.Zye3R0PNcI5Sz3LysiVG', '2d28a092717011eca9f1604', '保密', 2, NULL, '2022-01-09');
INSERT INTO `user` VALUES (1003, 'lat', '$2a$10$I8di/aHlISsn4.NVq7EM.OaeIge53HoORoxVF1SPA2fW6vHmLceUO', '469e3242717011eca9f1604', '男', 1, NULL, '2022-01-09');
INSERT INTO `user` VALUES (1007, 'andrew', '$2a$10$5tuzlccpAvkxnOlCR37JZeXsK/Q0AKRzpE1bnOr5EQUntvxrVTVgG', 'c361cdf89fc311ec8d37604', '保密', 2, NULL, '2022-03-10');

-- ----------------------------
-- Table structure for userfile
-- ----------------------------
DROP TABLE IF EXISTS `userfile`;
CREATE TABLE `userfile`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `filename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `size` bigint(0) NOT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `downloadcount` int(0) NOT NULL DEFAULT 0,
  `uploadtime` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of userfile
-- ----------------------------
INSERT INTO `userfile` VALUES (4, 'f347a91c716f11eca9f1604', 'd7592bb988ce4258b98cb37337aa7c6c.png', 'image/png', 6900267, '2022-03-08/', 2, '2022-03-09 15:14:50');
INSERT INTO `userfile` VALUES (5, 'f347a91c716f11eca9f1604', 'c83f81c3485948389a4117d3a04fdbc0.png', 'image/png', 1523561, '2022-03-08/', 1, '2022-03-09 03:43:14');
INSERT INTO `userfile` VALUES (6, 'f347a91c716f11eca9f1604', '6b0fbd55f51f4d1ebaa8595265f6b2bc.jpg', 'image/jpeg', 300372, '2022-03-08/', 2, '2022-03-09 03:36:48');
INSERT INTO `userfile` VALUES (10, 'f347a91c716f11eca9f1604', '58f25d24d44740b68b984d1d17c75426.txt', 'text/plain', 1157, '2022-03-09/', 2, '2022-03-09 03:43:39');
INSERT INTO `userfile` VALUES (11, 'f347a91c716f11eca9f1604', 'c4ab8966382241e58db7873f0b3efdb4.7z', 'application/octet-stream', 12380221, '2022-03-09/', 9, '2022-03-09 16:01:17');
INSERT INTO `userfile` VALUES (12, 'f347a91c716f11eca9f1604', '49137476231d426385060a21f3887072.java', 'application/octet-stream', 7297, '2022-03-09/', 12, '2022-03-10 00:13:47');

SET FOREIGN_KEY_CHECKS = 1;
