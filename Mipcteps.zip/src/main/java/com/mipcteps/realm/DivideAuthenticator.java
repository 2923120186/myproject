package com.mipcteps.realm;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.pam.AtLeastOneSuccessfulStrategy;
import org.apache.shiro.authc.pam.AuthenticationStrategy;
import org.apache.shiro.authc.pam.ModularRealmAuthenticator;
import org.apache.shiro.realm.Realm;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicReference;

@Component
public class DivideAuthenticator extends ModularRealmAuthenticator {

    @Override
    protected AuthenticationInfo doAuthenticate(AuthenticationToken token) throws AuthenticationException {
        Realm realm = null;
        Collection<Realm> realms = super.getRealms();
        for (Realm r : realms) {
            if (r.supports(token)) {
                realm = r;
                break;
            }
        }
        return super.doSingleRealmAuthentication(realm,token);
    }

    /*设置一个realm认证成功即可
    @Override
    public AuthenticationStrategy getAuthenticationStrategy() {
        return new AtLeastOneSuccessfulStrategy();
    }*/
}