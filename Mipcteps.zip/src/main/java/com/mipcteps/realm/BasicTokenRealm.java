package com.mipcteps.realm;

import com.auth0.jwt.exceptions.AlgorithmMismatchException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.mipcteps.common.Constants;
import com.mipcteps.common.model.entity.*;
import com.mipcteps.common.storage.CacheStorage;
import com.mipcteps.common.utils.ServletUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authc.pam.UnsupportedTokenException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Collection;

@Component
public class BasicTokenRealm extends AuthorizingRealm {

    public static final Logger log = LoggerFactory.getLogger(BasicTokenRealm.class);

    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof UserAuthToken;
    }

    @Override
    public CredentialsMatcher getCredentialsMatcher() {
        return (token, info) -> {
            return true;
        };
    }

    @Autowired
    CacheStorage cacheStorage;

    @Override
    public AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        UserTokenHolder<User> holder = null;
        try {
            ServletUtils.JwtUtils.verifyToken(token.getPrincipal().toString());
            holder = ServletUtils.JwtUtils.parseToken();
        } catch (Exception e) {
            if (e instanceof SignatureVerificationException || e instanceof AlgorithmMismatchException) {
                throw new IncorrectCredentialsException();
            }
            throw new ExpiredCredentialsException("认证已超时！");
        }
        User user = holder.getUser();
        String loginId = cacheStorage.getCacheValue(new String[]{Constants.USER_ID+user.getUserId()},String.class);
        if (StringUtils.hasText(loginId)) {
            if (holder.getLoginId().equals(loginId)) {
                return new SimpleAuthenticationInfo(holder, null, super.getName());
            }
            throw new ConcurrentAccessException("此账号已在别处登录！");
        }
        throw new ExpiredCredentialsException("认证已超时！");
    }

    /*处理Token验证是否符合，之后在处理授权问题*/
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        //获取信息
        UserTokenHolder holder = principalCollection.oneByType(UserTokenHolder.class);
        User user = holder.getUser();
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        Role role = user.getRole();
        info.addRole(role.getRoleName());
        for (Authorize authorize : role.getAuthorizes()) {
            info.addStringPermission(authorize.getAuthorizeName());
        }
        /* 登陆成功后查询对应的信息 获取当前用户的信息
        Subject subject = SecurityUtils.getSubject();
        //设置角色
        Set<String> setRole = new HashSet<>();
        //赋予角色是什么
        setRole.add(user.getAccount().getRole());
        //设置权限
        Set<String> setPerm = new HashSet<>();
        setPerm.add(user.getAccount().getPerms());*/
        return info;
    }

    @Override
    public void onLogout(PrincipalCollection principals) {
        UserTokenHolder holder = principals.oneByType(UserTokenHolder.class);
        User user = holder.getUser();
        String userId =  user.getUserId();
        if (cacheStorage.removeCacheValue(new String[]{Constants.USER_ID+userId})) {
            log.info(user.getUsername()+"用户以登出");
        }
    }


}
