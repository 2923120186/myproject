package com.mipcteps.realm;

import com.mipcteps.common.utils.PwdEncoder;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authc.credential.CredentialsMatcher;

public class UserEnctypeMatcher implements CredentialsMatcher {

    @Override
    public boolean doCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) {
        String password = new String((char[]) token.getCredentials());
        String pwd = info.getCredentials().toString();
        return PwdEncoder.verifyPwd(password, pwd);
    }

}
