package com.mipcteps.realm;

import com.mipcteps.common.model.entity.Authorize;
import com.mipcteps.common.model.entity.Role;
import com.mipcteps.common.model.entity.User;
import com.mipcteps.common.model.service.UserService;
import org.apache.logging.log4j.Logger;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.realm.AuthenticatingRealm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
public class UserRealm extends AuthenticatingRealm {

    @Override
    public boolean supports(AuthenticationToken token){
        return token.getClass().isAssignableFrom(UsernamePasswordToken.class);
    }

    /*设置密码匹配器*/
    @Override
    public CredentialsMatcher getCredentialsMatcher() {
        return new UserEnctypeMatcher();
    }

    @Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;

    /*处理登录身份登录授权认证令牌，可以强制转换成这个类的实例对象
    UsernamePasswordToken upt = (UsernamePasswordToken) token;*/
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        //将用户名称传过来
        User user = userService.findOneUserFromTheUserName(token.getPrincipal().toString());
        if(user != null){
            /*将查出的用户信息放入参数1中，将查出的密码放入参数2中，参数3属于加密盐的实现类
            参数4属于当前区域的名称不定义会指定使用CachingRealm类定义的getName()方法*/
            Role role = userService.queryRolesByUserId(user.getUserId());
            role.setAuthorizes(userService.findAuthorityByRoleId(role.getRoleId()));
            user.setRole(role);
            return new SimpleAuthenticationInfo(user,user.getPassword(),this.getName());
        } else{
            throw new UnknownAccountException("用户名错误！");
        }
    }

}
