package com.mipcteps.controller;

import com.google.code.kaptcha.Producer;
import com.mipcteps.common.AjaxResult;
import com.mipcteps.common.Constants;
import com.mipcteps.common.ResultGenerator;
import com.mipcteps.common.model.entity.User;
import com.mipcteps.common.model.entity.UserTokenHolder;
import com.mipcteps.common.model.service.UserService;
import com.mipcteps.common.storage.CacheStorage;
import com.mipcteps.common.utils.ServletUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping(value = "/user")
public class UserController {

    /* 用户视图对象 */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class UserVo implements Serializable {
        private String username;
        private String password;
        private String verifyCode;
    }

    @Autowired
    CacheStorage cacheStorage;

    @PostMapping(value = "/login")
    public AjaxResult<String> usersLogin(HttpServletRequest request,HttpServletResponse response){
        String verifyId = request.getHeader(Constants.VERIFY_CODE_HOLDER);
        if(StringUtils.isEmpty(verifyId) || !StringUtils.hasText(verifyId)) {
            return ResultGenerator.ErrorResult("未携带登录凭证！");
        }
        UserVo vo = ServletUtils.requestBody(request, UserVo.class);
        String referCode = cacheStorage.getCacheValue(new String[]{verifyId}, String.class);
        if(vo.getVerifyCode().equalsIgnoreCase(referCode)){
            Subject subject = SecurityUtils.getSubject();
            subject.login(new UsernamePasswordToken(vo.getUsername(),vo.getPassword()));
            User principal = (User) subject.getPrincipal();
            String loginId = verifyId+referCode;
            loginId = DigestUtils.md5DigestAsHex(loginId.getBytes());
            cacheStorage.setCacheKeyValue(new String[]{Constants.USER_ID+principal.getUserId()},loginId,Constants.loginIdExpiredTime);
            String token = ServletUtils.JwtUtils.tokenGenerator(principal,loginId);
            response.setHeader("token",token);
            return ResultGenerator.SuccessResult();
        }else{
            log.info("验证码有误");
            return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"验证码错误");
        }
    }

    //加载用户的信息
    @RequiresUser
    @GetMapping(value = "/loaduser")
    public AjaxResult<User> loadUserInfos(){
        Subject subject = SecurityUtils.getSubject();
        //获取用户的信息
        UserTokenHolder holder = subject.getPrincipals().oneByType(UserTokenHolder.class);
        User user = holder.getUser();
        log.info("目前用户数据："+user.toString());
        return ResultGenerator.SuccessResult(user);
    }

    @Autowired
    private Producer producer;

    /*用户验证码 */
    @GetMapping(value = "/referverifycode")
    public void referVerifyCode(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String verifyId = request.getParameter(Constants.VERIFY_CODE_HOLDER);
        response.setDateHeader("Expires", 30*1000);
        /* 设置标准的HTTP1.1无缓存标头。
        设置响应属性 不让浏览器进行缓存*/
        response.setHeader("Pragma","no-cache");
        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        // Set IE extended HTTP/1.1 no-cache headers (use addHeader).
        response.addHeader("Cache-Control", "post-check=0, pre-check=0");
        //响应内容的类型
        response.setContentType("image/jpeg");
        String text = producer.createText();
        BufferedImage bi = producer.createImage(text);
        cacheStorage.setCacheKeyValue(new String[]{verifyId},text,30L);
        OutputStream ops = response.getOutputStream();
        ImageIO.write(bi,"jpg",ops);
        ops.flush();
        ops.close();
    }

    @Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;

    @Data
    static class UserRegisterVO implements Serializable {

        @Size(min = 3,max = 6,message = "用户名长度必须在3和6位数之间")
        @NotBlank(message = "用户名不能为空！")
        String username;

        @Size(min = 3,max = 6,message = "密码长度必须在3和6位数之间")
        @NotBlank(message = "密码不能为空！")
        String password;

        @Max(value = 3,message = "权限代码不能大于4")
        Integer authorityId;

        @Size(max = 2,message = "性别必须在2位数之间")
        @NotBlank
        String gender;

        String description;
    }


    /*注册新的用户*/
    @PostMapping(value = "/register")
    public AjaxResult userRegister(@Validated @RequestBody UserRegisterVO vo){
        User user = userService.findOneUserFromTheUserName(vo.getUsername());
        if(user == null){
            user = new User()
                    .setUsername(vo.getUsername())
                    .setPassword(vo.getPassword())
                    .setAuthorityId(vo.getAuthorityId())
                    .setSex(vo.getGender())
                    .setDescription(vo.getDescription());
            int count = userService.createOneNewUser(user);
            if (count > 0) {
                return ResultGenerator.SuccessResult().setMessage("成功");
            }
            return ResultGenerator.ErrorResult(Constants.RESULT_CODE_BAD_REQUEST,"注册失败");
        }else {
            return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"此用户名已被注册！");
        }
    }

    /*加载登录信息*/
    @GetMapping(value = "/getverifyinfo")
    public AjaxResult<String> getVerifyInfo(HttpServletRequest request) {
        String verifyId = DigestUtils.md5DigestAsHex(request.getSession().getId().getBytes());
        return ResultGenerator.SuccessResult("成功",verifyId);
    }

    //退出登录状态
    @RequiresAuthentication
    @GetMapping(value ="/logout")
    public AjaxResult logout() {
        log.info("退出登录");
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        return ResultGenerator.SuccessResult();
    }


    @RequiresUser
    @PutMapping  ("/changeuserinfobyid")
    public AjaxResult changeUserInfoById(@RequestParam String username, @RequestParam String sex,
                                         @RequestParam String description,HttpServletResponse resp) throws Exception {
        Subject subject = SecurityUtils.getSubject();
        UserTokenHolder holder = subject.getPrincipals().oneByType(UserTokenHolder.class);
        User user = holder.getUser();
        user.setUsername(username);
        user.setSex(sex);
        user.setDescription(description);
        int count = userService.alterOneUserByUserId(user);
        if (count > 0) {
            String loginId = UUID.randomUUID().toString().replace("-", "");
            cacheStorage.setCacheKeyValue(new String[]{Constants.USER_ID+user.getUserId()},loginId,Constants.loginIdExpiredTime);
            String token = ServletUtils.JwtUtils.tokenGenerator(user, loginId);
            resp.setHeader(Constants.AUTH_TOKEN,token);
            return ResultGenerator.SuccessResult();
        }
        return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"修改失败");
    }

}

