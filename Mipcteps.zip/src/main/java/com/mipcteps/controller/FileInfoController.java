package com.mipcteps.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mipcteps.common.AjaxResult;
import com.mipcteps.common.Constants;
import com.mipcteps.common.ResultGenerator;
import com.mipcteps.common.model.entity.User;
import com.mipcteps.common.model.entity.UserFile;
import com.mipcteps.common.model.entity.UserTokenHolder;

import com.mipcteps.common.model.service.UserFileService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresGuest;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;


@RestController
@RequestMapping("/fileinfos")
public class FileInfoController {

    @Autowired
    @Qualifier("userFileServiceImpl")
    UserFileService userFileService;

    @RequiresAuthentication
    @GetMapping(value = "/getallfileinfos")
    public AjaxResult<Collection<UserFile>> getAllFileInfos(){
        Collection<UserFile> userFiles = userFileService.findAllUserFile();
        if(CollectionUtils.isEmpty(userFiles)){
            return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"目前没有任何的文件请上传");
        }
        return ResultGenerator.SuccessResult("成功",userFiles);
    }

    /*文件存储目录*/
    @Value("${resource.path}")
    private String filePath;

    /* 上传问题补充
    https://blog.csdn.net/qq_36595528/article/details/88806885 */
    @RequiresPermissions("sys:info:save")
    @PostMapping(value = "/uploads")
    public AjaxResult<List<String>> fileUploads(@RequestParam("files") MultipartFile[] files) {
        if (files != null && files.length > 0) {
            String pathDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "/";
            List<String> uploadFailOfName = new ArrayList<>();
            List<UserFile> userFiles = new ArrayList<>();
            Subject subject = SecurityUtils.getSubject();
            User user = subject.getPrincipals().oneByType(UserTokenHolder.class).getUser();
            for (MultipartFile file : files) {
                //获取文件的类型的后缀 例如 XX.jpg
                String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
                //创建新文件名称
                String newFilename = UUID.randomUUID().toString().replace("-", "")+ suffix;
                try {
                    File upload = new File(filePath + pathDate + newFilename);
                    if (!upload.exists()) {
                        upload.mkdirs();
                    }
                    //填写路径，将文件上传在盘符路径上
                    file.transferTo(upload);
                    userFiles.add(new UserFile(user.getUserId(),
                            newFilename,file.getContentType(),file.getSize(),pathDate));
                } catch (IOException e) {
                    uploadFailOfName.add(file.getOriginalFilename());
                }
            }
            int count = userFileService.addInMuchUserFile(userFiles);
            if (count > 0) {
                AjaxResult<List<String>> ajaxResult = ResultGenerator.SuccessResult("上传成功");
                if(uploadFailOfName.size() > 0){
                    ajaxResult.setData(uploadFailOfName);
                }
                return ajaxResult;
            }else {
                return ResultGenerator.ErrorResult("你的文件未上传成功！");
            }
        }else {
            return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR, "请选择文件！");
        }
    }
     
    @RequiresRoles("admin")
    @DeleteMapping(value = "/droponefilebyid/{id}")
    public AjaxResult dropOneFileById(@PathVariable Integer id) {
        UserFile userFile = userFileService.findOneUserFileById(id);
        if(userFile != null) {
            int count = userFileService.removeInOneUserFileFromId(id);
            if (count > 0) {
                File file = new File(filePath+userFile.getPath()+userFile.getFilename());
                if (file.delete()) {
                    return ResultGenerator.SuccessResult("删除成功");
                }
            }
            return ResultGenerator.ErrorResult("文件未删除请重试！");
        }
        return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"该文件存在未找到的异样！");
    }


    @GetMapping(value = "/downloadfile/{filename}")
    public void downloadFile(@PathVariable String filename, HttpServletResponse resp) throws IOException {
        InputStream is = null;
        UserFile userFile = userFileService.findOneUserFileByFromFilename(filename);
        if(userFile != null){
            try {
                int count = userFileService.fromFilenameAlterOneUserFileDownloadCount(filename);
                if(count > 0){
                    ServletOutputStream sops = resp.getOutputStream();
                    /*resp.setContentType("application/force-download");
                    resp.setContentType("multipart/form-data");*/
                    resp.setContentType("application/octet-stream");
                    resp.setHeader("Content-Disposition","attachment;fileName="+filename);
                    is = new FileInputStream(new File(filePath+userFile.getPath()+filename));
                    byte[] bytes = new byte[1024];
                    int len;
                    while ((len = is.read(bytes)) != -1){
                        sops.write(bytes,0,len);
                    }
                    sops.flush();
                    ioAssertClose(is,sops);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        /*也可以使用以下几种下载方式
        byte[] content = new byte[is.available()];
        is.read(content);
        sops.write(content);
        使用复制的方式
        FileCopyUtils.copy(file.getInputStream(),new FileOutputStream(new File(filePath+newName)));*/
    }

    @GetMapping("/filepreview/{filename}")
    public void filePreview(@PathVariable String filename,HttpServletResponse resp) {
        InputStream is = null;
        try {
            UserFile userFile = userFileService.findOneUserFileByFromFilename(filename);
            if(userFile != null) {
                resp.reset();
                File file = new File(filePath + userFile.getPath() + filename);
                resp.addHeader("Content-Disposition","inline;fileName=" + filename);
                resp.setContentLength((int) file.length());
                is = new FileInputStream(file);
                ServletOutputStream sops = resp.getOutputStream();
                byte[] content = new byte[1024*4];
                int len ;
                while ((len = is.read(content)) != -1){
                    sops.write(content,0,len);
                }
                sops.flush();
                ioAssertClose(is,sops);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void ioAssertClose(Closeable... closes){
        for (Closeable closeable : closes){
            if (closeable != null) {
                try {
                    closeable.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
