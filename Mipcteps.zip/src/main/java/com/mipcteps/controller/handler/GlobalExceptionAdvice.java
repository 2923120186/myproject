package com.mipcteps.controller.handler;

import com.mipcteps.common.AjaxResult;
import com.mipcteps.common.Constants;
import com.mipcteps.common.ResultGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.ShiroException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.UnauthenticatedException;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;


@Slf4j
@RestControllerAdvice
public class GlobalExceptionAdvice {

    /* shiro常见异常处理
    处理认证（登录）的全局异常
    AuthenticationException
    权限异常
    AuthorizationException
    UnauthorizedException*/
    @ExceptionHandler(value = ShiroException.class)
    public AjaxResult globalSecureHandler(ShiroException e){
        if(e instanceof AuthenticationException) {
            if (e instanceof UnknownAccountException || e instanceof IncorrectCredentialsException) {
                log.info(e.getMessage());
                return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR, "用户名或密码错误!");
            }
        }
        if(e instanceof AuthorizationException) {
            if(e instanceof UnauthenticatedException){
                return ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"尚未认证！");
            }
            if (e instanceof UnauthorizedException) {
                log.info("没有权限");
                return ResultGenerator.ErrorResult(Constants.RESULT_CODE_NO_AUTHORIZE_ERROR, "你没有权限");
            }
        }
        log.info("安全异常");
        return ResultGenerator.FailResult("服务器安全错误！");
    }

    /*参数异常处理
    BindException
    WebExchangeBindException*/
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public AjaxResult validatedParamHandler(MethodArgumentNotValidException e) throws Exception{
        log.info(e.getMessage());
        BindingResult bindingResult = e.getBindingResult();
        List<FieldError> fieldErrors = bindingResult.getFieldErrors();
        for (FieldError fieldError : fieldErrors) {
            System.out.println(fieldError.getDefaultMessage());
        }
        FieldError fieldError = fieldErrors.get(0);
        String defaultMessage = fieldError.getDefaultMessage();
        return ResultGenerator.ErrorResult( defaultMessage);
    }



}
