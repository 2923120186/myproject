package com.mipcteps.controller.filter;

import com.mipcteps.common.AnonMatchPathBuilder;
import com.mipcteps.common.Constants;
import com.mipcteps.common.ResultGenerator;
import com.mipcteps.common.model.entity.UserAuthToken;
import com.mipcteps.common.model.entity.UserTokenHolder;
import com.mipcteps.common.utils.ServletUtils;
import lombok.SneakyThrows;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.BearerHttpAuthenticationFilter;
import org.apache.shiro.web.util.WebUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;


/*定义过滤器可以继承这两个类
BasicHttpAuthenticationFilter
AuthenticatingFilter*/
@Component
public class BasicAuthTokenFilter extends BearerHttpAuthenticationFilter {

    /*预处理*/
    @Override
    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {
        HttpServletRequest req = WebUtils.toHttp(request);
        HttpServletResponse resp = WebUtils.toHttp(response);
        ServletUtils.preCorsHandler(req,resp);
        return super.preHandle(request, response);
    }

    @Autowired
    AnonMatchPathBuilder anonMatchPathBuilder;

    /*关键方法必须重写访问每个请求都会进入这里*/
    @SneakyThrows
    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        HttpServletResponse resp = WebUtils.toHttp(response);
        HttpServletRequest req = WebUtils.toHttp(request);
        /*将不需要认证请求路径的放行*/
        if(anonMatchPathBuilder.executeAnonymousMatch(req)){
            return true;
        }
        try {
            this.executeLogin(request,resp);
        } catch (Exception e) {
            if (e.getClass().isAssignableFrom(UnknownAccountException.class)) {
                ServletUtils.httpWriteOutJson(WebUtils.toHttp(response),ResultGenerator.ErrorResult(Constants.RESULT_CODE_NOT_LOGIN,"请登录！"));
                return false;
            }
            ServletUtils.httpWriteOutJson(resp,ResultGenerator.ErrorResult(Constants.RESULT_CODE_PARAM_ERROR, e.getMessage()));
            return false;
        }
        return super.isAccessAllowed(req,response,mappedValue);
    }

    @Override
    protected boolean executeLogin(ServletRequest request, ServletResponse response) throws Exception  {
        AuthenticationToken token = this.createToken(request, response);
        if (token != null) {
            Subject subject = SecurityUtils.getSubject();
            subject.login(token);
        }
        return true;
    }

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) {
        String token = WebUtils.toHttp(request).getHeader(Constants.AUTH_TOKEN);
        if (StringUtils.hasText(token) && !token.equals("null")) {
            return new UserAuthToken(token);
        }
        throw new UnknownAccountException();
    }

    /*isAccessAllowed方法返回为false就会进入这个方法里
    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        return false;
    }*/

}
