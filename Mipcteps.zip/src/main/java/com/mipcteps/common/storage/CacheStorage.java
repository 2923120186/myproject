package com.mipcteps.common.storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class CacheStorage {

    @Autowired
    @Qualifier("redisTemplate")
    RedisTemplate redisTemplate;


    @Autowired
    @Qualifier("stringRedisTemplate")
    StringRedisTemplate stringRedisTemplate;


    public void setCacheKeyValue(String[] key,Object value,Long time){
        if (value instanceof String) {
            if(key.length == 1){
                ValueOperations<String, String> valueOperations = stringRedisTemplate.opsForValue();
                if (time != null && time > 0) {
                    valueOperations.set(key[0],value.toString(),time,TimeUnit.SECONDS);
                }
            }
        }
    }

    public <T> T getCacheValue(String[] key,Class<T> type){
        if (type.isAssignableFrom(String.class)) {
            ValueOperations<String, String> valueOperations = stringRedisTemplate.opsForValue();
            String value = valueOperations.get(key[0]);
            return (T) value;
        }
        return null;
    }

    public boolean removeCacheValue(String[] key) {
        if (key.length > 1) {
            HashOperations hashOperations = redisTemplate.opsForHash();
            Long count = hashOperations.delete(key[0], key[1]);
            if (count > 0) {
                return true;
            }
        }
        Boolean delete = stringRedisTemplate.delete(key[0]);
        return delete;
    }


    public boolean setCacheKeyExpiredTime(Long time,String  key) {
        Boolean isSetExpire = stringRedisTemplate.expire(key, time, TimeUnit.SECONDS);
        return isSetExpire;
    }


}
