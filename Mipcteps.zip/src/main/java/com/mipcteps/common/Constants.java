package com.mipcteps.common;

/*响应属性参数 StatusCode */
public interface Constants {

    //成功处理请求
    public static final int RESULT_CODE_SUCCESS = 200;

    //请求失败
    public static final int RESULT_CODE_BAD_REQUEST = 412;

    //未登录
    public static final int RESULT_CODE_NOT_LOGIN = 402;

    //参数错误
    public static final int RESULT_CODE_PARAM_ERROR = 406;

    //服务器错误
    public static final int RESULT_CODE_SERVER_ERROR = 500;

    //无权限
    public static final int RESULT_CODE_NO_AUTHORIZE_ERROR = 312;

    //验证代码持有者
    public static final String VERIFY_CODE_HOLDER = "verifyid";

    //用户令牌
    public static final String AUTH_TOKEN = "token";

    //用户Id
    public static final String USER_ID = "userId:";

    public static final Long loginIdExpiredTime = 7*24*60*60L;



}
