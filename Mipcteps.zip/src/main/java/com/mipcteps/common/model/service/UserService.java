package com.mipcteps.common.model.service;

import com.mipcteps.common.model.entity.Authorize;
import com.mipcteps.common.model.entity.Role;
import com.mipcteps.common.model.entity.User;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import java.util.Collection;
import java.util.List;

public interface UserService {

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = true, rollbackFor = Exception.class)
    User findOneUserFromTheUserName(String username);

    @Transactional(rollbackFor = Exception.class)
    int createOneNewUser(User u);

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = true, rollbackFor = Exception.class)
    Role queryRolesByUserId(String userId);

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = true, rollbackFor = Exception.class)
    Collection<Authorize> findAuthorityByRoleId(Integer RoleId) ;

    @Transactional(rollbackFor = Exception.class)
    public int alterOneUserByUserId(User user);

}
