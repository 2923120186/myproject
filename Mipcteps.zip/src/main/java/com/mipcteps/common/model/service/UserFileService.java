package com.mipcteps.common.model.service;


import com.mipcteps.common.model.entity.UserFile;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

public interface UserFileService {

    public Collection<UserFile> findAllUserFile();

    public int addInMuchUserFile(List<UserFile> userFiles);

    @Transactional(rollbackFor = Exception.class)
    int removeInOneUserFileFromId(Integer id);

    UserFile findOneUserFileById(Integer id);

    UserFile findOneUserFileByFromFilename(String filename);

    @Transactional(rollbackFor = Exception.class)
    int fromFilenameAlterOneUserFileDownloadCount(String filename);


}
