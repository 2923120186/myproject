package com.mipcteps.common.model.mapper;

import com.mipcteps.common.model.entity.UserFile;

import java.util.List;

public interface UserFileMapper {

    List<UserFile> selectAllUserFileById(Integer id);

    Integer deleteFileByFileName(String filename);

    int insertBatchUserFile(UserFile[] userFiles);

    int deleteOneUserFileById(Integer id);

    UserFile selectOneUserFileByFileName(String filename);

    int updateOneUserFileDownloadCountByFileName(String filename);

}
