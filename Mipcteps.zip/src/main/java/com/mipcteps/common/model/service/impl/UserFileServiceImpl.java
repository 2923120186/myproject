package com.mipcteps.common.model.service.impl;



import com.mipcteps.common.model.entity.UserFile;
import com.mipcteps.common.model.mapper.UserFileMapper;

import com.mipcteps.common.model.service.UserFileService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

@Transactional
@Service
public class UserFileServiceImpl implements UserFileService {

    @Autowired
    private UserFileMapper userFileMapper;

    public Collection<UserFile> findAllUserFile(){
        return userFileMapper.selectAllUserFileById(null);
    }

    @Override
    public int addInMuchUserFile(List<UserFile> userFiles){
        return userFileMapper.insertBatchUserFile(userFiles.toArray(new UserFile[]{}));
    }

    @Override
    public int removeInOneUserFileFromId(Integer id) {
        return userFileMapper.deleteOneUserFileById(id);
    }

    @Override
    public UserFile findOneUserFileById(Integer id) {
        List<UserFile> userFiles = userFileMapper.selectAllUserFileById(id);
        return userFiles.get(0);
    }

    @Override
    public UserFile findOneUserFileByFromFilename(String filename) {
        return userFileMapper.selectOneUserFileByFileName(filename);
    }

    @Override
    public int fromFilenameAlterOneUserFileDownloadCount(String filename) {
        return userFileMapper.updateOneUserFileDownloadCountByFileName(filename);
    }



}
