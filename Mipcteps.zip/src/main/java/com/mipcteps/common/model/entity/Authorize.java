package com.mipcteps.common.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Authorize implements Serializable {

    private Integer authorizeId;

    private String authorizeName;

    public Authorize(String authorizeName) {
        this.authorizeName = authorizeName;
    }

}
