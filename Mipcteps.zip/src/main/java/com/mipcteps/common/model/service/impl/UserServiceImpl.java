package com.mipcteps.common.model.service.impl;

import com.mipcteps.common.model.entity.Authorize;
import com.mipcteps.common.model.entity.Role;
import com.mipcteps.common.model.entity.User;
import com.mipcteps.common.model.mapper.RoleMapper;
import com.mipcteps.common.model.mapper.UserMapper;
import com.mipcteps.common.model.service.UserService;
import com.mipcteps.common.utils.PwdEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.Collection;

@Transactional
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User findOneUserFromTheUserName(String username) {
        return userMapper.selectOneUserFromTheUsername(username);
    }

    @Override
    public int createOneNewUser(User u) {
        u.setPassword(PwdEncoder.pwdEncrypt(u.getPassword()));
        return userMapper.insertOneUser(u);
    }


    @Autowired
    private RoleMapper roleMapper;

    @Override
    public Role queryRolesByUserId(String userId) {
        return roleMapper.selectRoleByUserId(userId);
    }

    @Override
    public Collection<Authorize> findAuthorityByRoleId(Integer RoleId) {
        return roleMapper.selectAuthorityByRoleId(RoleId);
    }

    @Override
    public int alterOneUserByUserId(User user) {
        return userMapper.updateOneUserByUserId(user);
    }



}
