package com.mipcteps.common.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.pagehelper.PageInfo;
import com.mipcteps.common.AjaxResult;
import com.mipcteps.common.ResultGenerator;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


@Data
@NoArgsConstructor
@Accessors(chain = true)
public class UserFile implements Serializable {

     private Long id;

     private String userId;

     private String filename;

     private String type;

     private Long size;

     private String path;

     private Integer downloadCount;


     @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
     @JsonFormat(timezone = "GMT+8",pattern = "yyyy-MM-dd HH:mm:ss")
     private Date uploadTime;

     public UserFile(String userId,String filename,String type,Long size,String path){
          this.userId = userId;
          this.filename = filename;
          this.type = type;
          this.size = size;
          this.path = path;
    }


}
