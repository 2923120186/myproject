package com.mipcteps.common.model.entity;

import lombok.Data;

@Data
public class UserTokenHolder<T extends User> {

    private String loginId;

    private T user;

    private Long expiredTime;


}
