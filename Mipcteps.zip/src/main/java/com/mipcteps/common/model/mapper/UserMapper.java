package com.mipcteps.common.model.mapper;

import com.mipcteps.common.model.entity.Authorize;
import com.mipcteps.common.model.entity.Role;
import com.mipcteps.common.model.entity.User;
import java.util.List;


public interface UserMapper {

    User selectOneUserFromTheUsername(String username);

    int insertOneUser(User u);

    int updateOneUserByUserId(User user);

}
