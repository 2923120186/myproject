package com.mipcteps.common.model.entity;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.apache.shiro.authc.Account;
import org.springframework.context.annotation.Scope;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class User implements Serializable{

    private Integer id;

    private String username;

    private String password;

    private String userId;

    private String sex;

    private Integer authorityId;

    private String description;

    /*日期类型的参数接收和返回（响应输出）格式 HH:mm:ss*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(timezone = "GMT+8",pattern = "yyyy-MM-dd")
    private Date createDate;

    private Role role;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }


}
