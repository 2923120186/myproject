package com.mipcteps.common;

import com.mipcteps.common.utils.ServletUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.stream.Collectors;


public class AnonMatchPathBuilder {

    private Map<String,String> anonLinkPath = null;

    public AnonMatchPathBuilder() {
        anonLinkPath = new Hashtable<>();
    }

    public void addAnonymousPath(String path) {
        this.anonLinkPath.put(path,"anon");
    }


    public Map<String,String> getAnonymousPath() {
        return this.anonLinkPath;
    }

    public String[] getOpenPath(){
        Set<String> strings = anonLinkPath.keySet();
        return strings.toArray(new String[]{});
    }


    public boolean executeAnonymousMatch(HttpServletRequest request) {
        if(!ServletUtils.requestOpenPathMatcher(request, getOpenPath())) {
            return true;
        }
        /*进行后缀的路径匹配*/
        String[] openPath = getOpenPath();
        for (String path : openPath) {
            if (path.endsWith("/**")) {
                String contains = path.substring(path.indexOf("/"), path.lastIndexOf("/"));
                String uri = request.getRequestURI();
                if (uri.contains(contains)) {
                    return true;
                }
            }
        }
        return false;
    }

}
