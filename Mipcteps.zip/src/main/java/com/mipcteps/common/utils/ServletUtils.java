package com.mipcteps.common.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.Verification;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.mipcteps.common.AjaxResult;


import com.mipcteps.common.Constants;
import com.mipcteps.common.model.entity.Authorize;
import com.mipcteps.common.model.entity.Role;
import com.mipcteps.common.model.entity.User;
import com.mipcteps.common.model.entity.UserTokenHolder;
import org.junit.Test;

import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMethod;


import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;


public class ServletUtils {

    /* 跨域设置 */
    public static void preCorsHandler(HttpServletRequest request, HttpServletResponse response){
        String origin = request.getHeader("Origin");
        response.setHeader("Access-Control-Allow-Origin",origin);
        response.setHeader("Access-Control-Max-Age","3600");
        response.setHeader("Access-Control-Allow-Headers","*");
        response.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS");
        response.setHeader("Access-Control-Credentials","true");
        response.setHeader("Access-Control-Expose-Headers", Constants.AUTH_TOKEN+","+Constants.VERIFY_CODE_HOLDER);
        if(request.getMethod().equalsIgnoreCase(RequestMethod.OPTIONS.toString())){
            return;
        }
    }

    public static <T extends AjaxResult> void httpWriteOutJson(HttpServletResponse response,T t){
        String json = JsonUtils.objectToJsonString(t);
        response.setContentType("text/json;charset=utf-8");
        try {
            ServletOutputStream ops = response.getOutputStream();
            ops.write(json.getBytes());
            ops.flush();
            ops.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*json取值处理  @RequestBody String jsonData
    JSONObject jsonObject = JSON.parseObject(jsonData);
    String username =  jsonObject.getString("username");
    String password = jsonObject.getString("password");
    String verifcode = jsonObject.getString("captcha");*/
    public static <T> T requestBody(HttpServletRequest request,Class<T> type) {
        StringBuffer sb = new StringBuffer();
        T t = null;
        try {
            BufferedReader reader = request.getReader();
            String json = "";
            while ((json = reader.readLine()) != null){
                sb.append(json);
            }
            t = JsonUtils.parseJsonStringAsObject(sb.toString(),type);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return t;
    }

    public static boolean requestOpenPathMatcher(HttpServletRequest request,String... openPaths){
        String uri = request.getRequestURI();
        for (String openPath : openPaths) {
            if (uri.equals(openPath)) {
                return false;
            }
        }
        return true;
    }

    public static class JsonUtils{

        private static final ObjectMapper om = new ObjectMapper();

        public static <T> String objectToJsonString(T t){
            if(!(t instanceof String)) {
                String json = null;
                try {
                    json = om.writeValueAsString(t);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
                return json;
            }
            return t.toString();
        }

        public static <T> T parseJsonStringAsObject(String jsonText,Class<T> cType){
            T t = null;
            try {
                t = om.readValue(jsonText, cType);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            return t;
        }

    }

    public static class JwtUtils{

        private static String privateSecretKey = "j1h0lsgdo6fp13g8vpa51qqjxud9iur3tcq";

        private static long expiredTime = 7*24*60*60*1000;

        static final String userKey = "userPrincipal";

        static final String loginIdKey = "loginId";

        public static Long refreshTime = 24*60*60*1000L;

        public static String tokenGenerator(User user,String loginId){
            JWTCreator.Builder builder = JWT.create();
            builder.withIssuer(user.getUsername());
            /*操作其他jwt的参数
            builder.withSubject(user.getUserId());
            builder.withAudience(loginId);*/
            builder.withClaim(userKey,JsonUtils.objectToJsonString(user));
            builder.withClaim(loginIdKey,loginId);
            builder.withIssuedAt(new Date(System.currentTimeMillis()));
            builder.withExpiresAt(new Date(System.currentTimeMillis()+expiredTime));
            String sign = builder.sign(Algorithm.HMAC256(privateSecretKey));
            return sign;
        }

        private static ThreadLocal<DecodedJWT> decodeThread = new ThreadLocal<>();

        /*JWTVerificationException*/
        public static void verifyToken(String token){
            DecodedJWT decode = decodeThread.get();
            if(decode == null) {
                try {
                    Verification require = JWT.require(Algorithm.HMAC256(privateSecretKey));
                    JWTVerifier build = require.build();
                    decode = build.verify(token);
                }catch (Exception e) {
                    throw e;
                }
            }
            decodeThread.set(decode);
        }

        public static <T extends User> UserTokenHolder<T> parseToken(){
            UserTokenHolder<T> holder = null;
            DecodedJWT decode = decodeThread.get();
            if(decode != null) {
                holder = new UserTokenHolder<T>();
                /*decode.getAudience().get(0);
                 decode.getIssuer();
                 decode.getSubject(); */
                User user = JsonUtils.parseJsonStringAsObject(decode.getClaim(userKey).asString(),User.class);
                holder.setUser((T) user);
                holder.setLoginId(decode.getClaim(loginIdKey).asString());
                holder.setExpiredTime(decode.getExpiresAt().getTime());
                decodeThread.set(null);
            }
            return holder;
        }
    }



    @Test
    public void contextLoads() throws JsonProcessingException {
        /*
        DateFormat datetime = DateFormat.getDateTimeInstance();
        System.out.println(datetime.format(date));

        ConfigurableApplicationContext run = SpringApplication.run(MipctepsApplication.class);
        UserService userServiceImpl = (UserService) run.getBean("userServiceImpl");*/

        /*String token =
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpbklkIjoiOWRjMzcyZjM2NzI5NDQxMGVlYmIyZWE5NDhhMmNjZDQiLCJpc3MiOiJ5cmMiLCJleHAiOjE2NDU5NTA1ODksInVzZXJQcmluY2lwYWwiOiJ7XCJpZFwiOjEwMDEsXCJ1c2VybmFtZVwiOlwieXJjXCIsXCJwYXNzd29yZFwiOlwiJDJhJDEwJFhIc1UxT2duTWxIbHo3eGYzQVVwL3VFbE1YS0s3clRrdGZhcFRyLy9zcVF2WlhJeHEvSGZDXCIsXCJ1c2VySWRcIjpcImYzNDdhOTFjNzE2ZjExZWNhOWYxNjA0XCIsXCJzZXhcIjpcIuS_neWvhlwiLFwiYXV0aG9yaXR5SWRcIjoxLFwiZGVzY3JpcHRpb25cIjpudWxsLFwiY3JlYXRlRGF0ZVwiOlwiMjAyMi0wMS0wOVwiLFwicm9sZVwiOntcInJvbGVJZFwiOjIsXCJyb2xlTmFtZVwiOlwibWFuYWdlXCIsXCJhdXRob3JpemVJZFwiOjEsXCJhdXRob3JpemVzXCI6W3tcImF1dGhvcml6ZUlkXCI6MSxcImF1dGhvcml6ZU5hbWVcIjpcInN5czppbmZvOmVkaXRcIn0se1wiYXV0aG9yaXplSWRcIjoxLFwiYXV0aG9yaXplTmFtZVwiOlwic3lzOmluZm86c2F2ZVwifSx7XCJhdXRob3JpemVJZFwiOjEsXCJhdXRob3JpemVOYW1lXCI6XCJzeXM6aW5mbzpyZW1vdmVcIn1dfX0iLCJpYXQiOjE2NDUzNDU3ODl9.K_2hooFpob_-TJXRNphoquQa39xHcx7V6OsK4zRfEI8";
        JwtUtils.verifyToken(token);
        UserTokenHolder<User> holder = JwtUtils.parseToken();*/

        LocalDate now = LocalDate.now();
        System.out.println(now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        String filename = "/user/data/**";
        char[] chars = filename.toCharArray();
        int index = 0;
        for (int i = chars.length-1; i >=0 ; i--) {
            if (chars[i] == '/') {
                index = i;
                break;
            }
        }


    }

}
