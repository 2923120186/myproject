package com.mipcteps.common.utils;

import org.mindrot.jbcrypt.BCrypt;

/* 密码编辑器 */
public class PwdEncoder {

    public static String pwdEncrypt(String password){
         return BCrypt.hashpw(password,BCrypt.gensalt());
    }

    public static boolean verifyPwd(String password,String encPwd){
        return BCrypt.checkpw(password, encPwd);
    }

}
