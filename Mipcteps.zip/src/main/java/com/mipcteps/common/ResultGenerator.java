package com.mipcteps.common;

import org.springframework.util.StringUtils;

/* 返回响应工具 */
public class ResultGenerator {

    private static final String DEFAULT_SUCCESS_MESSAGE = "success";

    private static final String DEFAULT_FAIL_MESSAGE = "fail";

    public static AjaxResult SuccessLimit(AjaxResult result){
        result.setStatusCode(Constants.RESULT_CODE_SUCCESS);
        return result;
    }

    public static <T> AjaxResult<T> SuccessResult(T data){
        AjaxResult<T> result = new AjaxResult<T>();
        result.setStatusCode(Constants.RESULT_CODE_SUCCESS);
        result.setData(data);
        return result;
    }


    public static AjaxResult SuccessResult(){
        AjaxResult result = new AjaxResult();
        result.setStatusCode(Constants.RESULT_CODE_SUCCESS);
        result.setMessage(DEFAULT_SUCCESS_MESSAGE);
        return result;
    }

    public static <T> AjaxResult<T> SuccessResult(String message,T data){
        AjaxResult<T> result = new AjaxResult<T>();
        result.setStatusCode(Constants.RESULT_CODE_SUCCESS);
        result.setData(data);
        if(StringUtils.isEmpty(message)) {
            result.setMessage(DEFAULT_SUCCESS_MESSAGE);
            return result;
        }
        result.setMessage(message);
        return result;
    }

    public static AjaxResult SuccessResult(String message){
        AjaxResult result = new AjaxResult();
        result.setStatusCode(Constants.RESULT_CODE_SUCCESS);
        result.setMessage(message);
        return result;
    }

    /* 失败结果 */
    public static AjaxResult FailResult(String message){
        AjaxResult result = new AjaxResult();
        result.setStatusCode(Constants.RESULT_CODE_SERVER_ERROR);
        if(StringUtils.isEmpty(message)){
            result.setMessage(DEFAULT_FAIL_MESSAGE);
        }else {
            result.setMessage(message);
        }
        return result;
    }

    public static AjaxResult ErrorResult(String message){
        AjaxResult result = new AjaxResult();
        result.setStatusCode(Constants.RESULT_CODE_BAD_REQUEST);
        result.setMessage(message);
        return result;
    }

    public static AjaxResult ErrorResult(int code,String message){
        AjaxResult result = new AjaxResult();
        result.setStatusCode(code);
        result.setMessage(message);
        return result;
    }

}
