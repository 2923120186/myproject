package com.mipcteps.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class AjaxResult<T> implements Serializable {

    /* resultCode */
    private int statusCode;
    private String message;
    private T data;
    //分页的行
    private Integer count;


    public AjaxResult(int statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
    }

    public AjaxResult failure(String code){
        System.out.println(code);
        return new AjaxResult(500,"服务器错误");
    }

}
