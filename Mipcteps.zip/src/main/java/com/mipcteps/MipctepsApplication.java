package com.mipcteps;

import org.junit.jupiter.api.Test;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@EnableTransactionManagement
@MapperScan(basePackages = "com.mipcteps.common.model.mapper")
@SpringBootApplication
@SpringBootTest
public class MipctepsApplication {

    private static Logger log = LoggerFactory.getLogger(MipctepsApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(MipctepsApplication.class,args);
        log.info("启动中");
    }



}
