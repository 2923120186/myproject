package com.mipcteps.config;


import org.apache.shiro.subject.Subject;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSubjectFactory;
import org.springframework.stereotype.Component;

@Component
public class StatelessDefaultWebSubjectFactory extends DefaultWebSubjectFactory {

    /*设置无状态*/
    @Override
    public Subject createSubject (SubjectContext context) {
        context.setSessionCreationEnabled(false);
        return super.createSubject(context);
    }

}
