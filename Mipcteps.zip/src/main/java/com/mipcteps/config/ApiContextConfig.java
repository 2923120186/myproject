package com.mipcteps.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

/*开启webmvc配置注解适用前后分离将对没有进行handler处理
@EnableWebMvc*/
@Configuration
public class ApiContextConfig implements WebMvcConfigurer {

    /*启用静态资源默认servlet去处理*/
    @Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }

    @Value("${resource.path}")
    private String path;

    /*配置静态资源处理器
    HandlerInterceptor的preHandle方法的参数handler在处理静态资源请求的时候
    就会强转成 ResourceHttpRequestHandler类*/
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/source/**")
                .addResourceLocations("file:"+path);
    }

}
