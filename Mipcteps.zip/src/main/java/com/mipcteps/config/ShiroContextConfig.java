package com.mipcteps.config;



import com.mipcteps.common.AnonMatchPathBuilder;
import com.mipcteps.controller.filter.BasicAuthTokenFilter;
import com.mipcteps.realm.BasicTokenRealm;
import com.mipcteps.realm.DivideAuthenticator;

import com.mipcteps.realm.UserRealm;

import org.apache.shiro.mgt.*;

import org.apache.shiro.realm.Realm;
import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.spring.web.config.DefaultShiroFilterChainDefinition;

import org.apache.shiro.spring.web.config.ShiroFilterChainDefinition;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.mgt.WebSecurityManager;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;


import javax.servlet.Filter;
import java.util.*;

/*shiro配置完善体系*/
@Configuration
public class ShiroContextConfig {

    @Bean
    @ConditionalOnBean(name = "basicAuthTokenFilter")
    public ShiroFilterFactoryBean shiroFilterFactoryBean(
            @Qualifier("defaultWebSecurityManager") WebSecurityManager webSecurityManager,
            @Qualifier("definition") ShiroFilterChainDefinition chainDefinition,
            @Qualifier("basicAuthTokenFilter") BasicAuthTokenFilter authFilter  ) {
        ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
        /*Map<String, Filter> filters = new  LinkedHashMap<>();*/
        Map<String, Filter> filters = bean.getFilters();
        filters.put("authToken",authFilter);
        /*bean.setFilters(filters);*/
        bean.setFilterChainDefinitionMap(chainDefinition.getFilterChainMap());
        bean.setSecurityManager(webSecurityManager);
        return bean;
    }

    @Bean
    public AnonMatchPathBuilder anonMatchPathBuilder(){
        AnonMatchPathBuilder builder = new AnonMatchPathBuilder();
        builder.addAnonymousPath("/");
        builder.addAnonymousPath("/user/register");
        builder.addAnonymousPath("/user/login");
        builder.addAnonymousPath("/user/referverifycode");
        builder.addAnonymousPath("/user/getverifyinfo");
        builder.addAnonymousPath("/fileinfos/downloadfile/**");
        builder.addAnonymousPath("/fileinfos/filepreview/**");
        builder.addAnonymousPath("/source/**");
        return builder;
    }

    @Bean
    public DefaultShiroFilterChainDefinition definition
            (@Qualifier("anonMatchPathBuilder") AnonMatchPathBuilder anonMatchPathBuilder){
        Map<String,String> pathMap = new LinkedHashMap<>();
        pathMap.putAll(anonMatchPathBuilder.getAnonymousPath());
        pathMap.put("/**","authToken");
        DefaultShiroFilterChainDefinition definition = new DefaultShiroFilterChainDefinition();
        definition.addPathDefinitions(pathMap);
        return definition;
    }

    @Bean
    public DefaultWebSecurityManager defaultWebSecurityManager(
            @Qualifier("divideAuthenticator") DivideAuthenticator authenticator,
            @Qualifier("userRealm") UserRealm userRealm,
            @Qualifier("basicTokenRealm") BasicTokenRealm tokenRealm,
            @Qualifier("statelessDefaultWebSubjectFactory") SubjectFactory factory)
    {
        /*@Qualifier("defaultWebSessionManager") SessionManager sessionManager
        manager.setSessionManager(sessionManager); */

        DefaultWebSecurityManager manager = new DefaultWebSecurityManager();

        /*设置各项领域的缓存关闭 */
        userRealm.setCachingEnabled(false);
        userRealm.setAuthenticationCachingEnabled(false);
        tokenRealm.setCachingEnabled(false);
        tokenRealm.setAuthenticationCachingEnabled(false);
        tokenRealm.setAuthorizationCachingEnabled(false);

        /* 设置无状态subjectfactory*/
        manager.setSubjectFactory(factory);

        /*关闭session */
        DefaultSessionStorageEvaluator evaluator = new DefaultSessionStorageEvaluator();
        evaluator.setSessionStorageEnabled(false);
        DefaultSubjectDAO subjectDAO = new DefaultSubjectDAO();
        subjectDAO.setSessionStorageEvaluator(evaluator);
        manager.setSubjectDAO(subjectDAO);

        /*先设置验证器*/
        manager.setAuthenticator(authenticator);
        List<Realm> realms = new ArrayList<>();
        realms.add(userRealm);
        realms.add(tokenRealm);
        manager.setRealms(realms);
        return manager;
    }

    /*关闭session的创建
    @Bean
    public DefaultWebSessionManager defaultWebSessionManager(){
        DefaultWebSessionManager manager = new DefaultWebSessionManager();
        manager.setSessionValidationSchedulerEnabled(false);
        manager.setSessionIdCookieEnabled(true);
        manager.setSessionIdUrlRewritingEnabled(true);
        return manager;
    }*/

    @Bean
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator(){
        DefaultAdvisorAutoProxyCreator creator = new DefaultAdvisorAutoProxyCreator();
        creator.setProxyTargetClass(true);
        /*creator.setUsePrefix(true);*/
        return creator;
    }

    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor
            (@Qualifier("defaultWebSecurityManager") WebSecurityManager webSecurityManager){
        AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
        advisor.setSecurityManager(webSecurityManager);
        return advisor;
    }

    @Bean
    public LifecycleBeanPostProcessor lifecycleBeanPostProcessor(){
        LifecycleBeanPostProcessor processor = new LifecycleBeanPostProcessor();
        return processor;
    }

}
